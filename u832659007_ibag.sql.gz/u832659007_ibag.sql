-- MariaDB dump 10.19  Distrib 10.11.7-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u832659007_ibag
-- ------------------------------------------------------
-- Server version	10.11.7-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articles_title_unique` (`title`),
  KEY `articles_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES
(1,1,'مشكلة النفايات ','<p dir=\"rtl\">في الوقت الحاضر، أصبحت النفايات الصلبة مشكلة كبيرة في ماليزيا. ومع ذلك، فإن معظم الناس في ماليزيا<br>ليسوا على علم ويأخذون هذه المشكلة كأمر مسلم به. تزايد عدد السكان والتنمية الهائلة<br>في السنوات الأخيرة ولدت بشكل غير مباشر قيمة هائلة من النفايات المنزلية، مما يجعل النفايات المنزلية<br>المولد الرئيسي للنفايات الصلبة في ماليزيا. وذكرت أن 5 بالمائة فقط من متوسط ​​30 ألف طن من النفايات<br>تم إعادة تدويرها في ماليزيا [1]. ونتيجة لذلك، فإن جميع النفايات الصلبة التي تم إنتاجها سوف يتم التخلص منها مباشرة<br>نقل إلى مكب النفايات.<br>تهدف السياسة الوطنية لإدارة النفايات الصلبة إلى تدشين نظام لإدارة النفايات الصلبة<br>والتي تكون متكاملة وشاملة ومربحة وقابلة للحياة مع أن تكون مقبولة للمجتمع. جي إس آر<br>الاستشارات البيئية شبكة التنمية المستدامة. Bhd. (GSR) بتكليف من Jabatan Pengurusan Sisa Pepejal Negara<br>(JPSPN) لإجراء مسح شامل حول تكوين النفايات الصلبة وخصائصها والممارسات الموجودة<br>إعادة تدوير النفايات الصلبة في ماليزيا في يوليو 2011 للتغلب على مشكلة إدارة النفايات [2].<br>على الرغم من الكم الهائل من النفايات المنتجة وتعقيدها، إلا أن معايير إدارة النفايات هي كذلك<br>لا تزال فقيرة وخاصة في ماليزيا. يوضح الشكل 1 المواد المعدنية المختلفة الموجودة في المنزل. الطريقة المستخدمة في<br>نظام إدارة النفايات أقل كفاءة مقارنة بالدول المتقدمة الأخرى. استخدام النفايات<br>يمكن لنظام الفصل بأقصى قدر من الكفاءة أن يزيد من نظام إدارة النفايات في بلدنا.<br>لسوء الحظ، لا يزال الماليزيون يفتقرون إلى الوعي بهذا النظام ولكن لا يزال هناك 15% منا على علم به</p>','2024-04-21 17:14:04','2024-04-21 17:14:04',NULL),
(2,1,'Voluptas sed et sapi','<p>Voluptas sed et sapi Labore consectetur alias minima aliquam voluptatem laudantium Labore consectetur alias minima aliquam voluptatem laudantium Voluptas sed et sapi Labore consectetur alias minima aliquam voluptatem laudantium Labore consectetur alias minima aliquam voluptatem laudantium Voluptas sed et sapi Labore consectetur alias minima aliquam voluptatem laudantium Labore consectetur alias minima aliquam voluptatem laudantium Voluptas sed et sapi Labore consectetur alias minima aliquam voluptatem laudantium Labore consectetur alias minima aliquam voluptatem laudantium Voluptas sed et sapi Labore consectetur alias minima aliquam voluptatem laudantium Labore consectetur alias minima aliquam voluptatem laudantium Voluptas sed et sapi Labore consectetur alias minima aliquam voluptatem laudantium Labore consectetur alias minima aliquam voluptatem laudantium&nbsp;</p>','2024-05-21 21:21:04','2024-05-21 21:21:04',NULL);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category_donation` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'food',1,'2024-05-10 11:33:32','2024-05-10 11:33:32'),
(2,'Coins',1,'2024-05-10 12:17:26','2024-05-10 12:17:26'),
(3,'Clothes',1,'2024-05-10 12:19:56','2024-05-10 12:19:56'),
(4,'Metal',0,'2024-05-10 12:24:24','2024-05-10 12:24:24'),
(5,'Organic',0,'2024-05-10 12:25:15','2024-05-10 12:25:15'),
(6,'In-Organic ',0,'2024-05-10 12:25:59','2024-05-10 12:25:59');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donation_category`
--

DROP TABLE IF EXISTS `donation_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donation_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `donation_id` bigint(20) unsigned NOT NULL,
  `estimated_kg` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `donation_category_category_id_foreign` (`category_id`),
  KEY `donation_category_donation_id_foreign` (`donation_id`),
  CONSTRAINT `donation_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donation_category_donation_id_foreign` FOREIGN KEY (`donation_id`) REFERENCES `donations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donation_category`
--

LOCK TABLES `donation_category` WRITE;
/*!40000 ALTER TABLE `donation_category` DISABLE KEYS */;
INSERT INTO `donation_category` VALUES
(1,1,1,'2','2024-05-10 12:14:33','2024-05-10 12:14:33');
/*!40000 ALTER TABLE `donation_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donations`
--

DROP TABLE IF EXISTS `donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `interval` varchar(255) NOT NULL,
  `remind_me` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `donations_user_id_foreign` (`user_id`),
  CONSTRAINT `donations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donations`
--

LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` VALUES
(1,'zagazig','zagazig','2024-05-15','8:00pm',1,3,NULL,'2024-05-10 12:14:33','2024-05-10 12:14:33',1,20);
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES
(1,'App\\Models\\User',3,'5fab8bb4-f6e5-4897-ac61-1604ae43560c','default','WhatsApp Image 2024-04-21 at 18.27.42_6b2fd98c','01HW0QSA5BVQPGYXC4Y8MB3T5G.jpg','image/jpeg','public','public',174407,'[]','[]','{\"preview\":true}','[]',1,'2024-04-21 16:28:17','2024-04-21 16:28:19'),
(2,'App\\Models\\User',4,'800785ec-c908-4972-a96c-6fb1ba37f20c','default','WhatsApp Image 2024-04-21 at 18.27.42_740edd25','01HW0QZZE00R0DFH5681ZCS8DE.jpg','image/jpeg','public','public',170659,'[]','[]','{\"preview\":true}','[]',1,'2024-04-21 16:31:56','2024-04-21 16:31:56'),
(4,'App\\Models\\Category',1,'8b41d9a2-6f20-4009-85bc-d3727eb9b2ae','default','184611','01HXH4F83983H00SBW3V59HWY6.jpg','image/jpeg','public','public',207378,'[]','[]','{\"preview\":true}','[]',1,'2024-05-10 11:33:32','2024-05-10 11:33:32'),
(5,'App\\Models\\Category',2,'04a40bae-0773-42d3-aa85-c97d7d1cacc9','default','20220206113234060','01HXH6ZMX75F44ZC1Q30P9DD5S.jpg','image/jpeg','public','public',47517,'[]','[]','{\"preview\":true}','[]',1,'2024-05-10 12:17:26','2024-05-10 12:17:27'),
(6,'App\\Models\\Category',3,'0ca840bf-1043-42e3-aea0-3f7d8e42bd66','default','images','01HXH746MKZHKTT921YTKWV1G2.jpg','image/jpeg','public','public',9606,'[]','[]','{\"preview\":true}','[]',1,'2024-05-10 12:19:56','2024-05-10 12:19:56'),
(7,'App\\Models\\Category',4,'bbe2df64-3bef-401d-8695-648102fdcd93','default','Screenshot 2024-05-10 152232','01HXH7CC9W2T5ZWJSDZW7QJT89.png','image/png','public','public',25706,'[]','[]','{\"preview\":true}','[]',1,'2024-05-10 12:24:24','2024-05-10 12:24:24'),
(8,'App\\Models\\Category',5,'8bd103d7-43c6-4d28-9fb1-86e58b118f7a','default','Screenshot 2024-05-10 152257','01HXH7DY8FQB7G0AYSMPDYNEMR.png','image/png','public','public',23081,'[]','[]','{\"preview\":true}','[]',1,'2024-05-10 12:25:15','2024-05-10 12:25:15'),
(9,'App\\Models\\Category',6,'0d7ae3b3-3d50-41d6-b49f-2ee15d562d9d','default','Screenshot 2024-05-10 152325','01HXH7F9GQ0F85X957D1MDVN0V.png','image/png','public','public',4046,'[]','[]','{\"preview\":true}','[]',1,'2024-05-10 12:25:59','2024-05-10 12:25:59'),
(10,'App\\Models\\Article',2,'c2b42278-4b6c-4c17-803a-f12d4ce4fcb6','default','Home-Page-Bottom','01HYEGEYPJK4WXVQ46HKE9WTKJ.png','image/png','public','public',190596,'[]','[]','{\"preview\":true}','[]',1,'2024-05-21 21:21:04','2024-05-21 21:21:04');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_reset_tokens_table',1),
(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),
(4,'2019_08_19_000000_create_failed_jobs_table',1),
(5,'2019_12_14_000001_create_personal_access_tokens_table',1),
(6,'2023_11_07_001922_create_sessions_table',1),
(7,'2023_11_07_005922_add_social_provider_column',1),
(8,'2023_11_07_010800_create_permission_tables',1),
(9,'2023_11_07_033559_add_softdeletes_to_users',1),
(10,'2024_03_24_140540_add_otp_to_users_table',1),
(11,'2024_03_24_144538_create_articles_table',1),
(12,'2024_03_24_145435_create_media_table',1),
(13,'2024_03_27_182950_create_donations_table',1),
(14,'2024_03_27_191600_create_categories_table',1),
(15,'2024_03_27_191759_create_donation_category_table',1),
(16,'2024_03_27_212532_create_orders_table',1),
(17,'2024_03_27_212545_create_order_category_table',1),
(18,'2024_03_27_213657_add_confirmed_in_orders_and_donations',1),
(19,'2024_03_27_215851_add_points_in_orders_and_donations',1),
(20,'2024_03_27_220431_create_partners_table',1),
(21,'2024_03_27_220944_create_technical_issues_table',1),
(22,'2024_03_27_222025_add_type_in_users',1),
(23,'2024_03_27_222922_add_mobile_and_address_in_users',1),
(24,'2024_05_17_203859_remove_required_from_some_fields_in_users',2),
(25,'2024_05_26_095229_add_first_and_last_names_in_users',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_category`
--

DROP TABLE IF EXISTS `order_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `estimated_kg` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_category_category_id_foreign` (`category_id`),
  KEY `order_category_order_id_foreign` (`order_id`),
  CONSTRAINT `order_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_category_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_category`
--

LOCK TABLES `order_category` WRITE;
/*!40000 ALTER TABLE `order_category` DISABLE KEYS */;
INSERT INTO `order_category` VALUES
(1,5,1,'3','2024-05-10 12:27:18','2024-05-10 12:27:18'),
(10,1,6,'50','2024-05-25 20:17:17','2024-05-25 20:17:17'),
(11,2,6,'60','2024-05-25 20:17:17','2024-05-25 20:17:17'),
(12,1,7,'50','2024-05-25 20:46:25','2024-05-25 20:46:25'),
(13,2,7,'60','2024-05-25 20:46:25','2024-05-25 20:46:25'),
(14,1,8,'50','2024-05-25 21:33:40','2024-05-25 21:33:40'),
(15,2,8,'60','2024-05-25 21:33:40','2024-05-25 21:33:40'),
(16,1,10,'50','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(17,1,11,'50','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(18,1,9,'50','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(19,1,12,'50','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(20,2,10,'60','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(21,2,9,'60','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(22,2,12,'60','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(23,2,11,'60','2024-05-28 23:51:19','2024-05-28 23:51:19'),
(24,1,13,'50','2024-05-28 23:51:24','2024-05-28 23:51:24'),
(25,2,13,'60','2024-05-28 23:51:24','2024-05-28 23:51:24'),
(26,1,14,'50','2024-05-28 23:51:25','2024-05-28 23:51:25'),
(27,2,14,'60','2024-05-28 23:51:25','2024-05-28 23:51:25'),
(28,1,15,'50','2024-05-28 23:51:26','2024-05-28 23:51:26'),
(29,2,15,'60','2024-05-28 23:51:26','2024-05-28 23:51:26'),
(30,1,16,'50','2024-05-28 23:51:28','2024-05-28 23:51:28'),
(31,2,16,'60','2024-05-28 23:51:28','2024-05-28 23:51:28'),
(32,1,17,'50','2024-05-28 23:51:38','2024-05-28 23:51:38'),
(33,2,17,'60','2024-05-28 23:51:38','2024-05-28 23:51:38'),
(34,1,18,'50','2024-05-28 23:51:39','2024-05-28 23:51:39'),
(35,2,18,'60','2024-05-28 23:51:39','2024-05-28 23:51:39'),
(36,1,20,'50','2024-05-29 00:22:53','2024-05-29 00:22:53'),
(37,1,19,'50','2024-05-29 00:22:53','2024-05-29 00:22:53'),
(38,2,20,'60','2024-05-29 00:22:53','2024-05-29 00:22:53'),
(39,2,19,'60','2024-05-29 00:22:53','2024-05-29 00:22:53'),
(40,1,21,'50','2024-05-29 00:22:54','2024-05-29 00:22:54'),
(41,2,21,'60','2024-05-29 00:22:54','2024-05-29 00:22:54'),
(42,1,22,'50','2024-05-29 00:22:57','2024-05-29 00:22:57'),
(43,2,22,'60','2024-05-29 00:22:57','2024-05-29 00:22:57'),
(44,1,23,'50','2024-05-29 00:22:57','2024-05-29 00:22:57'),
(45,2,23,'60','2024-05-29 00:22:57','2024-05-29 00:22:57'),
(46,1,24,'50','2024-05-29 00:22:57','2024-05-29 00:22:57'),
(47,2,24,'60','2024-05-29 00:22:57','2024-05-29 00:22:57'),
(48,1,25,'50','2024-05-29 00:26:14','2024-05-29 00:26:14'),
(49,2,25,'60','2024-05-29 00:26:14','2024-05-29 00:26:14'),
(50,1,26,'50','2024-05-29 00:26:15','2024-05-29 00:26:15'),
(51,2,26,'60','2024-05-29 00:26:15','2024-05-29 00:26:15'),
(52,1,27,'50','2024-05-29 00:26:15','2024-05-29 00:26:15'),
(53,2,27,'60','2024-05-29 00:26:15','2024-05-29 00:26:15'),
(54,1,28,'50','2024-05-29 00:26:16','2024-05-29 00:26:16'),
(55,2,28,'60','2024-05-29 00:26:16','2024-05-29 00:26:16'),
(56,1,29,'50','2024-05-29 00:26:16','2024-05-29 00:26:16'),
(57,2,29,'60','2024-05-29 00:26:16','2024-05-29 00:26:16');
/*!40000 ALTER TABLE `order_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `interval` varchar(255) NOT NULL,
  `remind_me` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,'Damietta','Damietta','2024-05-10','4:00pm',1,5,NULL,'2024-05-10 12:27:18','2024-05-10 12:27:18',1,30),
(6,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-25 20:17:17','2024-05-25 20:17:17',0,0),
(7,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-25 20:46:25','2024-05-25 20:46:25',0,0),
(8,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-25 21:33:40','2024-05-25 21:33:40',0,0),
(9,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:19','2024-05-28 23:51:19',0,0),
(10,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:19','2024-05-28 23:51:19',0,0),
(11,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:19','2024-05-28 23:51:19',0,0),
(12,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:19','2024-05-28 23:51:19',0,0),
(13,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:24','2024-05-28 23:51:24',0,0),
(14,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:25','2024-05-28 23:51:25',0,0),
(15,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:26','2024-05-28 23:51:26',0,0),
(16,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:28','2024-05-28 23:51:28',0,0),
(17,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:38','2024-05-28 23:51:38',0,0),
(18,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-28 23:51:39','2024-05-28 23:51:39',0,0),
(19,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:22:53','2024-05-29 00:22:53',0,0),
(20,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:22:53','2024-05-29 00:22:53',0,0),
(21,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:22:54','2024-05-29 00:22:54',0,0),
(22,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:22:57','2024-05-29 00:22:57',0,0),
(23,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:22:57','2024-05-29 00:22:57',0,0),
(24,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:22:57','2024-05-29 00:22:57',0,0),
(25,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:26:14','2024-05-29 00:26:14',0,0),
(26,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:26:15','2024-05-29 00:26:15',0,0),
(27,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:26:15','2024-05-29 00:26:15',0,0),
(28,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:26:16','2024-05-29 00:26:16',0,0),
(29,'Address','Location','2019-06-13','10:30 AM',1,32,NULL,'2024-05-29 00:26:16','2024-05-29 00:26:16',0,0);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partners_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=361 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(199,'view-any Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(200,'view-any Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(201,'view Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(202,'view Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(203,'create Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(204,'create Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(205,'update Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(206,'update Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(207,'delete Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(208,'delete Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(209,'restore Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(210,'restore Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(211,'force-delete Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(212,'force-delete Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(213,'replicate Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(214,'replicate Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(215,'reorder Article','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(216,'reorder Article','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(217,'view-any Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(218,'view-any Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(219,'view Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(220,'view Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(221,'create Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(222,'create Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(223,'update Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(224,'update Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(225,'delete Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(226,'delete Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(227,'restore Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(228,'restore Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(229,'force-delete Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(230,'force-delete Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(231,'replicate Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(232,'replicate Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(233,'reorder Category','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(234,'reorder Category','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(235,'view-any Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(236,'view-any Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(237,'view Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(238,'view Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(239,'create Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(240,'create Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(241,'update Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(242,'update Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(243,'delete Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(244,'delete Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(245,'restore Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(246,'restore Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(247,'force-delete Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(248,'force-delete Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(249,'replicate Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(250,'replicate Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(251,'reorder Donation','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(252,'reorder Donation','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(253,'view-any DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(254,'view-any DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(255,'view DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(256,'view DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(257,'create DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(258,'create DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(259,'update DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(260,'update DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(261,'delete DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(262,'delete DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(263,'restore DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(264,'restore DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(265,'force-delete DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(266,'force-delete DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(267,'replicate DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(268,'replicate DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(269,'reorder DonationCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(270,'reorder DonationCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(271,'view-any Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(272,'view-any Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(273,'view Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(274,'view Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(275,'create Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(276,'create Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(277,'update Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(278,'update Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(279,'delete Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(280,'delete Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(281,'restore Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(282,'restore Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(283,'force-delete Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(284,'force-delete Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(285,'replicate Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(286,'replicate Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(287,'reorder Order','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(288,'reorder Order','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(289,'view-any OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(290,'view-any OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(291,'view OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(292,'view OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(293,'create OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(294,'create OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(295,'update OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(296,'update OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(297,'delete OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(298,'delete OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(299,'restore OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(300,'restore OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(301,'force-delete OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(302,'force-delete OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(303,'replicate OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(304,'replicate OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(305,'reorder OrderCategory','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(306,'reorder OrderCategory','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(307,'view-any Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(308,'view-any Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(309,'view Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(310,'view Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(311,'create Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(312,'create Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(313,'update Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(314,'update Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(315,'delete Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(316,'delete Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(317,'restore Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(318,'restore Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(319,'force-delete Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(320,'force-delete Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(321,'replicate Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(322,'replicate Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(323,'reorder Partner','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(324,'reorder Partner','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(325,'view-any TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(326,'view-any TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(327,'view TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(328,'view TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(329,'create TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(330,'create TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(331,'update TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(332,'update TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(333,'delete TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(334,'delete TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(335,'restore TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(336,'restore TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(337,'force-delete TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(338,'force-delete TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(339,'replicate TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(340,'replicate TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(341,'reorder TechnicalIssue','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(342,'reorder TechnicalIssue','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(343,'view-any User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(344,'view-any User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(345,'view User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(346,'view User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(347,'create User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(348,'create User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(349,'update User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(350,'update User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(351,'delete User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(352,'delete User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(353,'restore User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(354,'restore User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(355,'force-delete User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(356,'force-delete User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(357,'replicate User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(358,'replicate User','api','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(359,'reorder User','web','2024-05-18 12:25:16','2024-05-18 12:25:16'),
(360,'reorder User','api','2024-05-18 12:25:16','2024-05-18 12:25:16');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES
(1,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','68dc297f7bfb83b64c1adc7a7d874c64243ed12dbdd12bf7e58475c6a26bf584','[\"*\"]',NULL,NULL,'2024-04-17 07:17:40','2024-04-17 07:17:40'),
(2,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','5474ee1e291fa562139ffc5ba80af05fd0c6d6038074162572a5dcd502c83a24','[\"*\"]','2024-04-17 07:17:52',NULL,'2024-04-17 07:17:45','2024-04-17 07:17:52'),
(3,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','a774e786323a76a9d36061907f1e4a6b826030dee90e70ea6a97d7ea3eaf65a3','[\"*\"]',NULL,NULL,'2024-04-27 21:16:23','2024-04-27 21:16:23'),
(4,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','2061686b6ed0de80bdc77b43a7ca1991f868798db0c540461a7369f6065a6775','[\"*\"]','2024-04-28 21:57:01',NULL,'2024-04-27 21:16:56','2024-04-28 21:57:01'),
(5,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','058808a5f5f9e01603145cf1a88eebf121cd580b3993906b91e33ff30ad1ba02','[\"*\"]',NULL,NULL,'2024-04-28 22:14:01','2024-04-28 22:14:01'),
(6,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','14c11eae7d0a3d8e7fe80255513c28e380518499d6c2cb30b0e8a55b852f1dab','[\"*\"]','2024-04-28 22:37:46',NULL,'2024-04-28 22:30:49','2024-04-28 22:37:46'),
(7,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','8d73c76297a541c19bd4844e401da076528bbcdbafd5462ffc25398db725880a','[\"*\"]','2024-04-29 10:27:22',NULL,'2024-04-29 10:26:34','2024-04-29 10:27:22'),
(8,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','2d534b3675977766bd0dd789ec2e7a2be7b8db210d3d06e0cd42cb58f3e2f1ee','[\"*\"]','2024-05-09 17:05:39',NULL,'2024-05-01 11:30:27','2024-05-09 17:05:39'),
(9,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','71b42bcfb81701faceb6ad2a254970766ee3f811883c33af53d9a239923cda9b','[\"*\"]',NULL,NULL,'2024-05-01 11:34:42','2024-05-01 11:34:42'),
(10,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','cdaa800937df60a4a73dbaee4d398d4b3231a43095eee2a0e7fe4eaccde71737','[\"*\"]',NULL,NULL,'2024-05-05 17:06:42','2024-05-05 17:06:42'),
(11,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','79eb194069cc3a95dfe0443418c6e26ed241979e4367bf49161540d5fe4d5ceb','[\"*\"]',NULL,NULL,'2024-05-05 17:13:15','2024-05-05 17:13:15'),
(12,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','a413b59bf9b5c5497a65c433002057cf9ea4d82439b11eb0f278f5f69827cb0e','[\"*\"]',NULL,NULL,'2024-05-05 17:14:50','2024-05-05 17:14:50'),
(13,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','2380fcc6948fe0315d4fbc3f77c84524e5b2a2b83afa0c9df1032d0567f392e9','[\"*\"]',NULL,NULL,'2024-05-09 17:05:40','2024-05-09 17:05:40'),
(14,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','6996800337c1d0393df76511c49284d387a7f855c860eef475111bfb4e37b272','[\"*\"]','2024-05-09 17:07:05',NULL,'2024-05-09 17:07:00','2024-05-09 17:07:05'),
(15,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','55953294ce1ab2c2b81fe3868947471b0bdce2aeecc3c231102e453631ebd51f','[\"*\"]',NULL,NULL,'2024-05-17 12:06:35','2024-05-17 12:06:35'),
(16,'App\\Models\\User',2,'Ahmed elsayed-AuthToken','fb4f56c1ccc5327657c337fa6e33950544b13cf9bc18c420462b5a2957895e3c','[\"*\"]',NULL,NULL,'2024-05-17 12:19:50','2024-05-17 12:19:50'),
(17,'App\\Models\\User',6,'Ahmed elsayed-AuthToken','51745840198a81359d95bf06140d5e18003ac735c68deff94eecce854fb872ce','[\"*\"]',NULL,NULL,'2024-05-17 15:34:55','2024-05-17 15:34:55'),
(18,'App\\Models\\User',7,'Ahmed elsayed-AuthToken','dd9e5705a39626ff4a9107806767aceb4ad9fb979f13a01cbc960da422bf4ee5','[\"*\"]',NULL,NULL,'2024-05-17 15:35:26','2024-05-17 15:35:26'),
(19,'App\\Models\\User',8,'Ahmed elsayed-AuthToken','13995d7630ae5142639112089f1a7f52da56a3eba19e7b034c512317e388d9aa','[\"*\"]',NULL,NULL,'2024-05-17 15:36:35','2024-05-17 15:36:35'),
(20,'App\\Models\\User',9,'Ahmed elsayed-AuthToken','40f7919a1db34e400baeb996d7101d6274b89121723210200c3d5aa8b34b8d06','[\"*\"]',NULL,NULL,'2024-05-17 15:37:41','2024-05-17 15:37:41'),
(21,'App\\Models\\User',9,'Ahmed elsayed-AuthToken','23e2efff6eb7f732628c56341cd70fd374ac68dd8135888a79f2235345bd605e','[\"*\"]',NULL,NULL,'2024-05-17 15:38:10','2024-05-17 15:38:10'),
(22,'App\\Models\\User',9,'Ahmed elsayed-AuthToken','fcd264cd98378598552891fe67d83f085e1616a6c0f294aea3a22667473ffdb0','[\"*\"]',NULL,NULL,'2024-05-17 16:37:28','2024-05-17 16:37:28'),
(23,'App\\Models\\User',10,'Ahmed elsayed-AuthToken','311b2a27bdeb6df4eb573767573617b3153d6f07a0db610d26858246bc3ee10b','[\"*\"]',NULL,NULL,'2024-05-17 19:47:25','2024-05-17 19:47:25'),
(24,'App\\Models\\User',11,'Ahmed elsayed-AuthToken','f80f7ba718624c88f21e81c4cc28f07c1c5b7d6590c6883bed331642c43364d6','[\"*\"]',NULL,NULL,'2024-05-17 20:07:53','2024-05-17 20:07:53'),
(25,'App\\Models\\User',11,'Ahmed elsayed-AuthToken','cbeca10de5fec574d45ab4317d2b8ac8152bf0a0ab0cf8c57e17e2e4385a1332','[\"*\"]',NULL,NULL,'2024-05-17 20:14:00','2024-05-17 20:14:00'),
(26,'App\\Models\\User',11,'Ahmed elsayed-AuthToken','efc8d99cbe71b213e333f85d6816e0387a899a0856a3706c506f8deae1c06883','[\"*\"]','2024-05-17 20:19:31',NULL,'2024-05-17 20:15:33','2024-05-17 20:19:31'),
(27,'App\\Models\\User',12,'Ahmed elsayed-AuthToken','880f30381cbda9ab28819b766a771ddaf08f21e8c098b8a595fb45110079b6e8','[\"*\"]',NULL,NULL,'2024-05-17 20:21:00','2024-05-17 20:21:00'),
(28,'App\\Models\\User',13,'Ahmed elsayed-AuthToken','0e110104ae608473053e48bb4b10b9d44a70fc43cc800a0946586b438c942b40','[\"*\"]',NULL,NULL,'2024-05-17 20:24:15','2024-05-17 20:24:15'),
(29,'App\\Models\\User',14,'Ahmed elsayed-AuthToken','82e99e3f42b60bf448924b9ef359b59cdcfa38e1d0c497810ea7bdf5c6279128','[\"*\"]',NULL,NULL,'2024-05-17 20:26:39','2024-05-17 20:26:39'),
(30,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','d2a2f5eaf3db9a4418bbb1b0fc6457ff70ea0a5c5bfcd7d2557a702318243732','[\"*\"]',NULL,NULL,'2024-05-17 20:26:53','2024-05-17 20:26:53'),
(31,'App\\Models\\User',23,'yehia-AuthToken','a9b101f2e911542932f0a11a8d9de5b5b7d12285baeedb7e755d1f8a19d9de6d','[\"*\"]',NULL,NULL,'2024-05-19 09:23:40','2024-05-19 09:23:40'),
(32,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','5af97b94ebce7cf0fb8f0f310dbd44026db4497285f28fed878dcc4f5d4aa992','[\"*\"]','2024-05-19 19:11:47',NULL,'2024-05-19 09:33:39','2024-05-19 19:11:47'),
(33,'App\\Models\\User',24,'-AuthToken','f5e2c1733b3ba99eb8ae5bbbaef24d9dff77e7f2acd4b0304c8cad675634df28','[\"*\"]',NULL,NULL,'2024-05-19 19:41:41','2024-05-19 19:41:41'),
(34,'App\\Models\\User',26,'-AuthToken','a454d55429439aaf303bf180f4d5bf31baa474c5a241667c97ea9eb8fa5c3ad1','[\"*\"]',NULL,NULL,'2024-05-19 19:44:31','2024-05-19 19:44:31'),
(35,'App\\Models\\User',27,'-AuthToken','e4758186fde787963de75802d43911cd102b8fce58717a6229e314f92148cf95','[\"*\"]',NULL,NULL,'2024-05-19 19:48:05','2024-05-19 19:48:05'),
(36,'App\\Models\\User',28,'-AuthToken','7ad2632dd6fec9eaf7243375d59240ef35d67456a1ee531db31f3d89a2cf7a9c','[\"*\"]',NULL,NULL,'2024-05-19 19:49:14','2024-05-19 19:49:14'),
(37,'App\\Models\\User',29,'-AuthToken','65d8057021cc37acd5498cd91bd2ec7a9791491370360a606430b86ea00db536','[\"*\"]',NULL,NULL,'2024-05-19 19:54:31','2024-05-19 19:54:31'),
(38,'App\\Models\\User',30,'-AuthToken','6bd8fa3ed987a544bf4bbdf17223e2d6bbcc8e21bc1a4072167a828d76d11fcd','[\"*\"]',NULL,NULL,'2024-05-19 20:26:10','2024-05-19 20:26:10'),
(39,'App\\Models\\User',31,'-AuthToken','bcbb1b218f68b5a29a245d3dbc857a6feb2d6a2d64731abe1d2d2cc69dd60967','[\"*\"]','2024-05-21 21:25:18',NULL,'2024-05-21 21:24:43','2024-05-21 21:25:18'),
(40,'App\\Models\\User',31,'-AuthToken','d0d79da380a58c8e1fd8e2b05d8a3402da91c675b784e2b70759a9a30f1b1919','[\"*\"]','2024-05-21 21:34:39',NULL,'2024-05-21 21:29:03','2024-05-21 21:34:39'),
(41,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','fd1010ee4a351544f1d1260dd74c5ff0d89efb57f58aa0884c76d993b7656739','[\"*\"]','2024-05-21 21:39:37',NULL,'2024-05-21 21:31:54','2024-05-21 21:39:37'),
(42,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','4188d975de3136cd3e9e2382293a8d97951b28db95f345a4ec1257e960b5f468','[\"*\"]','2024-05-22 17:26:03',NULL,'2024-05-22 07:51:01','2024-05-22 17:26:03'),
(43,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','fdd57f14b88a635635c046cde37c75f11c88e4a9d9aee6b5285dc12da9a164be','[\"*\"]',NULL,NULL,'2024-05-25 08:55:24','2024-05-25 08:55:24'),
(44,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','ada30434b32c6133b877f43f3e8e80ca9bf90c110aa2223af850f90d90bc042c','[\"*\"]','2024-05-25 17:27:18',NULL,'2024-05-25 12:29:29','2024-05-25 17:27:18'),
(45,'App\\Models\\User',15,'Ahmed elsayed-AuthToken','732a70fc8d4088f954c47175ba806f1b092722cff510dfcd112e02e2fa58a20f','[\"*\"]','2024-05-25 17:54:01',NULL,'2024-05-25 17:51:16','2024-05-25 17:54:01'),
(46,'App\\Models\\User',32,'-AuthToken','9715dc68cd85fda1383b3f2bba01427e17ef11bbc21200f8f4fe1b6d2d2f865d','[\"*\"]',NULL,NULL,'2024-05-25 18:03:09','2024-05-25 18:03:09'),
(47,'App\\Models\\User',32,'-AuthToken','046b63eb4e3f8bf2d942480637beb36c9d61f760f42466d9284c8698bbc90e3e','[\"*\"]','2024-05-29 00:26:16',NULL,'2024-05-25 18:04:54','2024-05-29 00:26:16'),
(48,'App\\Models\\User',31,'-AuthToken','7190f8ebd0fc5aa08afa0b49f51e176f37581f073a0a7b8e2cb1676759c0a322','[\"*\"]','2024-05-26 09:38:39',NULL,'2024-05-26 08:50:48','2024-05-26 09:38:39'),
(49,'App\\Models\\User',31,'a.elsayed.it@gmail.com-AuthToken','88637f879ca2c5e739acdd0198e0c2da0df0d9981af9ce196ac2e8f03f225361','[\"*\"]','2024-05-26 10:10:01',NULL,'2024-05-26 10:09:43','2024-05-26 10:10:01'),
(50,'App\\Models\\User',33,'a.elsayed.it@gmail.com-AuthToken','56150f560e3cc2434e239d7aca708bce8c45ff781c99a6fb7a7faf678ac011b6','[\"*\"]','2024-05-26 10:16:35',NULL,'2024-05-26 10:16:11','2024-05-26 10:16:35'),
(51,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','22b942524f00f2d74c049fedcf41452cb8f9b3a9779991acde53068cceb03eaa','[\"*\"]',NULL,NULL,'2024-05-26 16:56:17','2024-05-26 16:56:17'),
(52,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','17083537425fb9ff548e109a1136e03b3299eef4871366765b3e1a36e6b14e2b','[\"*\"]',NULL,NULL,'2024-05-26 17:49:44','2024-05-26 17:49:44'),
(53,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','b8dd82f4e79c8ed5d0eeedd06f53a1659636a733791787da8d3621d42ab74304','[\"*\"]',NULL,NULL,'2024-05-26 17:54:39','2024-05-26 17:54:39'),
(54,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','a033593e02ec159650df0594f2819093595a57151b23986d822d788372fb86bf','[\"*\"]',NULL,NULL,'2024-05-26 17:57:10','2024-05-26 17:57:10'),
(55,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','ea6571b1b8a3c79cf142580a04565f49637bf0d5a5c64da38f2aadaf47f589cb','[\"*\"]',NULL,NULL,'2024-05-26 18:21:56','2024-05-26 18:21:56'),
(56,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','94d67c656c8939e3e4c65f74ecf72507e1fdc83846f56015e1eb9e34f43b2393','[\"*\"]',NULL,NULL,'2024-05-26 18:24:42','2024-05-26 18:24:42'),
(57,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','83da0e6df6c1250c85db34d33e05148947728b1abe29eeb3bbd331d40806dcec','[\"*\"]',NULL,NULL,'2024-05-26 19:01:36','2024-05-26 19:01:36'),
(58,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','b63670be3748e9d8074f38f2e2656524da07e87717224e3238bb3b1a0046c017','[\"*\"]',NULL,NULL,'2024-05-26 19:02:07','2024-05-26 19:02:07'),
(59,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','c153309e830d6c63f69f8ec32e39bc4e0f178ae0e0219612a67408be35b91e86','[\"*\"]',NULL,NULL,'2024-05-26 19:08:14','2024-05-26 19:08:14'),
(60,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','61c1893f361473afa56d0476e41677761424eca5978d835bc8d14fa679be2141','[\"*\"]',NULL,NULL,'2024-05-26 19:11:20','2024-05-26 19:11:20'),
(61,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','24ab6b8c063586f1576f1b5797160ca4d7ee18cbf504e775f52e28cd837d4bce','[\"*\"]',NULL,NULL,'2024-05-26 19:23:17','2024-05-26 19:23:17'),
(62,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','4e8049e1199adafa2c7cbe8c9efd8255f5d1f006e8170266ddbf608e645d297e','[\"*\"]',NULL,NULL,'2024-05-26 19:23:42','2024-05-26 19:23:42'),
(63,'App\\Models\\User',34,'ys1925738@gmail.com-AuthToken','882f854383cb60d207a63953e9d136ed8aceca8f95a18190af91b6437a33074f','[\"*\"]',NULL,NULL,'2024-05-26 20:13:59','2024-05-26 20:13:59'),
(64,'App\\Models\\User',35,'yehia1122@gmail.com-AuthToken','cde17f2aec87efc24c17a04fcc4717fbb91fcc60b23f36e3a65116516b648ce1','[\"*\"]',NULL,NULL,'2024-05-26 20:19:44','2024-05-26 20:19:44'),
(65,'App\\Models\\User',34,'ys1925738@gmail.com-AuthToken','d7d843306e22db40a5a0f594fd8fd60cd4c69d69f7cdb0cccec859669d22e1da','[\"*\"]',NULL,NULL,'2024-05-26 20:20:17','2024-05-26 20:20:17'),
(66,'App\\Models\\User',36,'yehia123@gmail.com-AuthToken','cc9a567a746e592ed5038348760d0584521ddf4310b81f975c91607e14e61e7f','[\"*\"]',NULL,NULL,'2024-05-27 08:04:12','2024-05-27 08:04:12'),
(67,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','15a6a4a6d1333b654997cc190675f6bde2d045871a91758c593ed24f7b65b92c','[\"*\"]',NULL,NULL,'2024-05-27 08:05:14','2024-05-27 08:05:14'),
(68,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','113ce4b2a57ab18796d7fff1c2b4ca50356a407833a09a22bd95c8bec14aaae3','[\"*\"]',NULL,NULL,'2024-05-29 10:49:03','2024-05-29 10:49:03'),
(69,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','105859c8fae584a12d5ac7b531176e428faf3ecb13cfd19210aa2ce35a476581','[\"*\"]',NULL,NULL,'2024-05-29 11:46:11','2024-05-29 11:46:11'),
(70,'App\\Models\\User',23,'yehia12@gmail.com-AuthToken','5f889fc8c6ace748a8491c6bf8c853493fc3110bb358771be24434a42770c060','[\"*\"]',NULL,NULL,'2024-05-29 17:59:29','2024-05-29 17:59:29'),
(71,'App\\Models\\User',23,'yehia12@gmail.com-AuthToken','bfbb8bf04d6f4b2744336e85560b31f0f540263ee6763f65ab3b6a2d753ba5c4','[\"*\"]',NULL,NULL,'2024-05-29 18:01:13','2024-05-29 18:01:13'),
(72,'App\\Models\\User',15,'yehia01128445409@gmail.com-AuthToken','b29e5662781e044cf320f27ca4d3f6ebfa968625d7fc47aa6860881adac7a4fc','[\"*\"]',NULL,NULL,'2024-05-29 19:52:01','2024-05-29 19:52:01'),
(73,'App\\Models\\User',37,'yehia409@gmail.com-AuthToken','760820010041ba995ea7977199a9731924dfedf135d2711ae360b9d6be841e39','[\"*\"]',NULL,NULL,'2024-05-29 20:05:30','2024-05-29 20:05:30'),
(74,'App\\Models\\User',38,'yehia9@gmail.com-AuthToken','45c62542b861fd36288182c5e0b73b4d1d4acd2d9380825340ece81334caff1d','[\"*\"]',NULL,NULL,'2024-05-29 20:12:22','2024-05-29 20:12:22'),
(75,'App\\Models\\User',39,'yehia1234@gmail.com-AuthToken','90f972903f3db04b58a7d94424ebc3e16c2b1f60f1874125416ac9b47cc07839','[\"*\"]',NULL,NULL,'2024-05-30 09:35:08','2024-05-30 09:35:08'),
(76,'App\\Models\\User',40,'qwer@gmail.com-AuthToken','ce74999e79bfb616ed2b9625514a5ddf15b0418458efbbd9dc56a43f320039a0','[\"*\"]',NULL,NULL,'2024-05-30 09:41:48','2024-05-30 09:41:48'),
(77,'App\\Models\\User',41,'fddsfc@gmail.com-AuthToken','00134955ed8721e4abb36e6c28f3743fab74600273c003d9f2ff65ad127b78e5','[\"*\"]',NULL,NULL,'2024-05-30 09:52:54','2024-05-30 09:52:54'),
(78,'App\\Models\\User',42,'abdo12@gmail.com-AuthToken','8cf50d6ca21c4648250d70c804bc82415148e7a5a1ea370b8d8bcac2579db864','[\"*\"]',NULL,NULL,'2024-05-30 10:55:15','2024-05-30 10:55:15');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(204,4),
(204,5),
(208,4),
(208,5),
(210,4),
(210,5),
(212,4),
(212,5),
(214,4),
(214,5),
(216,4),
(216,5),
(222,4),
(222,5),
(226,4),
(226,5),
(228,4),
(228,5),
(230,5),
(232,4),
(232,5),
(234,4),
(234,5),
(240,4),
(240,5),
(244,4),
(244,5),
(246,4),
(246,5),
(248,4),
(248,5),
(250,4),
(250,5),
(252,4),
(252,5),
(258,4),
(258,5),
(262,4),
(262,5),
(264,4),
(264,5),
(266,4),
(266,5),
(268,4),
(268,5),
(270,4),
(270,5),
(276,4),
(276,5),
(280,4),
(280,5),
(282,4),
(282,5),
(284,5),
(286,4),
(286,5),
(288,4),
(288,5),
(294,4),
(294,5),
(298,5),
(302,4),
(302,5),
(304,4),
(304,5),
(306,4),
(306,5),
(312,4),
(312,5),
(316,5),
(320,4),
(320,5),
(322,4),
(322,5),
(324,4),
(324,5),
(330,4),
(330,5),
(334,4),
(334,5),
(338,4),
(338,5),
(340,4),
(340,5),
(342,4),
(342,5),
(348,4),
(348,5),
(352,5),
(356,4),
(356,5),
(358,4),
(358,5),
(360,4),
(360,5);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'admin','web','2023-11-07 02:24:32','2023-11-07 02:24:32'),
(4,'customer','api','2024-05-18 12:26:47','2024-05-18 12:26:47'),
(5,'provider','api','2024-05-18 12:27:13','2024-05-18 12:27:13');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `technical_issues`
--

DROP TABLE IF EXISTS `technical_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technical_issues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `technical_issues_user_id_foreign` (`user_id`),
  CONSTRAINT `technical_issues_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technical_issues`
--

LOCK TABLES `technical_issues` WRITE;
/*!40000 ALTER TABLE `technical_issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `technical_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `otp` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_provider` tinyint(1) NOT NULL DEFAULT 0,
  `mobile` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin',NULL,'admin@ibag.future-co.org',NULL,NULL,'$2y$12$/k3zgWXgydQZFRR/JWv7euWCOfopYlksaRyvY7GLhBSiVtJNekRMq',NULL,NULL,NULL,'GQo87A4kphKOlM9pgF367gZd5NL0XW6hXaAMiZI0Cktqp1KeK9Qszo7ryetI',NULL,NULL,'2024-03-20 23:07:31','2024-05-26 10:04:05',NULL,NULL,NULL,1,NULL,NULL),
(3,NULL,NULL,'elfar43@gmil.com',NULL,NULL,'$2y$12$VcbRBP0uhj3IO9qt.SlA2uJ6DKYohEnUzEvAy8NQ3uZCJLSolZDh2',NULL,NULL,NULL,NULL,NULL,NULL,'2024-04-21 16:28:17','2024-05-19 09:12:28',NULL,NULL,NULL,1,'01060434693','Damietta'),
(4,NULL,NULL,'aboamer.60@gmail.com',NULL,NULL,'$2y$12$B9jGrz/hbep2L1sr6VdTv.4wF8j0U7bFBjEGMlAOYtEoqmZYcq5KG',NULL,NULL,NULL,NULL,NULL,NULL,'2024-04-21 16:31:56','2024-04-21 16:31:56',NULL,NULL,NULL,1,'01283267085','zagazig'),
(5,NULL,NULL,'wal.15@gmail.com',NULL,NULL,'$2y$12$w7Y1asYCbYIqqMCw1x2GUe4BFqDZiO5o68Ud/6IxgFvFxHLBC1Bqq',NULL,NULL,NULL,NULL,NULL,NULL,'2024-04-27 19:14:49','2024-04-27 19:14:49',NULL,NULL,NULL,0,'01015478623',NULL),
(15,'yehia01128445409','yehia01128445409','yehia01128445409@gmail.com','2024-05-19 09:33:39',NULL,'$2y$12$VC4IstWLfg7ospRsmyfk.OI.ClAaQ827gTlHxuP0knpWNTChyQxOe',NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-17 20:26:53','2024-05-30 14:13:20',NULL,NULL,'2024-05-30 14:13:20',0,NULL,NULL),
(21,NULL,NULL,'sheila.hendrix@testing-mail.com',NULL,NULL,'$2y$12$7OZoTpNIM9nz72qX4lYAv.uqPFgQfhZQSiZQUu6tV23br0BhKX.gi',NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 09:19:42','2024-05-19 09:19:46',NULL,NULL,'2024-05-19 09:19:46',1,'Ea ducimus in delen','Odio et ratione eos '),
(23,NULL,NULL,'yehia12@gmail.com',NULL,NULL,'$2y$12$369CdwhkTyz.V/RVWdpFj..B7Lzf1T0QlG4pWFbYuEouzmw9pf/yC',NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 09:20:45','2024-05-29 17:57:27',NULL,NULL,NULL,1,'01128445409','zefta'),
(24,NULL,NULL,'yehia0112844@gmail.com',NULL,'177690',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 19:41:41','2024-05-30 11:18:21',NULL,NULL,NULL,0,NULL,NULL),
(26,NULL,NULL,'yehia011@gmail.com',NULL,'147473',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 19:44:31','2024-05-30 10:58:58',NULL,NULL,NULL,0,NULL,NULL),
(27,NULL,NULL,'yehia41@gmail.com',NULL,'539238',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 19:48:05','2024-05-19 19:48:05',NULL,NULL,NULL,0,NULL,NULL),
(28,NULL,NULL,'yehia9999@gmail.com',NULL,'896135',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 19:49:14','2024-05-19 19:49:14',NULL,NULL,NULL,0,NULL,NULL),
(29,NULL,NULL,'yehia123456@gmail.com',NULL,'284773',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 19:54:31','2024-05-19 20:09:39',NULL,NULL,NULL,0,NULL,NULL),
(30,NULL,NULL,'a.elsasyed.it@gmail.com',NULL,'944397',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-19 20:26:10','2024-05-19 20:26:10',NULL,NULL,NULL,0,NULL,NULL),
(32,NULL,NULL,'marammohamed196@gmail.com','2024-05-25 18:04:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-25 18:03:09','2024-05-25 18:04:54',NULL,NULL,NULL,0,NULL,NULL),
(33,'Ahmed','elsayed','a.elsayed.it@gmail.com','2024-05-26 10:16:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-26 10:16:11','2024-05-26 10:16:33',NULL,NULL,NULL,0,'01282054848','12 nasr city, cairo'),
(34,'youssef','sabry','ys1925738@gmail.com','2024-05-26 20:20:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-26 20:13:59','2024-05-29 20:13:37',NULL,NULL,'2024-05-29 20:13:37',0,'01064308389','zefta elgarbya'),
(35,'yehia','reda','yehia1122@gmail.com',NULL,'760777',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-26 20:19:44','2024-05-29 20:13:33',NULL,NULL,'2024-05-29 20:13:33',0,'01559286111','zefta'),
(36,'yehia','reda','yehia123@gmail.com',NULL,'155702',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-27 08:04:12','2024-05-29 20:13:40',NULL,NULL,'2024-05-29 20:13:40',0,'01128445409','15 zefta , elgarbia'),
(37,'yehia','reda','yehia409@gmail.com',NULL,'674675',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-29 20:05:30','2024-05-29 20:13:28',NULL,NULL,'2024-05-29 20:13:28',0,'01128445409','cairo'),
(38,'ddd','gff','yehia9@gmail.com',NULL,'611915',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-29 20:12:22','2024-05-29 20:13:30',NULL,NULL,'2024-05-29 20:13:30',0,'96884485001','asddrvg'),
(39,'abdo','reda','yehia1234@gmail.com',NULL,'431880',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-30 09:35:08','2024-05-30 09:35:08',NULL,NULL,NULL,0,'01128445409','zefta elgarbia'),
(40,'yehia','reda','qwer@gmail.com',NULL,'407400',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-30 09:41:48','2024-05-30 09:41:48',NULL,NULL,NULL,0,'01114886920','aqfgh'),
(41,'yrhia','fedf','fddsfc@gmail.com',NULL,'274072',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-30 09:52:54','2024-05-30 09:52:54',NULL,NULL,NULL,0,'01128445409','zefta'),
(42,'abdo','reda','abdo12@gmail.com',NULL,'380237',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-05-30 10:55:15','2024-05-30 10:55:15',NULL,NULL,NULL,0,'01145833706','zefta');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-30 14:15:29
